import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;

import static java.lang.System.out;

/**
 * This class represents a segment of the blockchain
 * containing information about a specific block node and its ancestors and descendants.
 */
public class BlockChainSegment {
    private final BlockChain.BlockNode blockNode; // The corresponding block node in the blockchain

    /**
     * Constructor to create a BlockChainSegment object.
     * @param blockNode The block node to create the clip from.
     */
    public BlockChainSegment(BlockChain.BlockNode blockNode){
        // The block associated with this clip
        Block block = blockNode.getNode_block();
        // The height of the block in the blockchain
        int height = blockNode.getNode_height();
        // The UTXO pool associated with this block
        UTXOPool utxoPool = blockNode.getNode_UTXOPool();
        // The parent node of this block node
        BlockChain.BlockNode fatherNode = blockNode.getNode_fatherNode();
        // The child nodes of this block node
        ArrayList<BlockChain.BlockNode> kidNodes = blockNode.getNode_kidNodes();
        this.blockNode = blockNode;
    }

    /**
     * Print the block chain clip by performing a Breadth-First Search (BFS).
     */
    public void printBlockChainSegment(){
        out.println("the tree structure of block chain:");
        BlockChain.printBFSSearch(this.blockNode);
    }

    /**
     * Perform Breadth-First Search (BFS) to print the blockchain tree structure.
     * @param blockNode The current block node being processed.
     */
    private void printBFSSearch(BlockChain.BlockNode blockNode) {
        Queue<BlockChain.BlockNode> queue = new ArrayDeque<>();
        queue.add(blockNode);

        int currentLevelCount = 1;
        int nextLevelCount = 0;

        while (!queue.isEmpty()) {
            BlockChain.BlockNode currentNode = queue.poll();
            out.print("Block hash is: " + currentNode.getNode_block().hashCode() + " ");

            currentLevelCount--;

            queue.addAll(currentNode.getNode_kidNodes());
            nextLevelCount += currentNode.getNode_kidNodes().size();

            if (currentLevelCount == 0) {
                out.println(); // Move to the next line after printing all nodes in the current level
                currentLevelCount = nextLevelCount;
                nextLevelCount = 0;
            }
        }
    }

}
