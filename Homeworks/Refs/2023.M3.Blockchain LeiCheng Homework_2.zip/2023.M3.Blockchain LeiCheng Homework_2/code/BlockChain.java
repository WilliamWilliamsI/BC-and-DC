// Block Chain should maintain only limited block nodes to satisfy the functions
// You should not have all the blocks added to the block chain in memory 
// as it would cause a memory overflow.

//import related modules

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;

import static java.lang.System.out;

public class BlockChain {
    public static final int CUT_OFF_AGE = 3; // reset for convenience of test
//    public static final in t CUT_OFF_AGE = 10;
    private TransactionPool GlobalTxPool; //a block collect transactions from Transaction Pool
    private BlockNode GenesisBlockNode;

    /**
     * create an empty block chain with just a genesis block.
     * Assume {@code genesisBlock} is a valid block
     */
    public BlockChain(Block genesisBlock) {
        // IMPLEMENT THIS
        // if the block chain is not null, return false.
        // Create a new BlockNode object with the provided genesis block.
        this.GenesisBlockNode = new BlockNode(genesisBlock);
        // Create a new TransactionPool object.
        this.GlobalTxPool = new TransactionPool();

        // add coinbase to UTXO pool
        // Retrieve the coinbase transaction from the genesis block.
        Transaction coinbaseTx = genesisBlock.getCoinbase();
        // Create a new UTXO object for the coinbase transaction.
        UTXO utxo = new UTXO(coinbaseTx.getHash(), 0);

        // Set the height of the GenesisBlockNode to 1.
        this.GenesisBlockNode.height = 1;
        // Add the coinbase transaction's output to the UTXO pool of the GenesisBlockNode.
        this.GenesisBlockNode.utxoPool.addUTXO(utxo, coinbaseTx.getOutput(0));
        // Add the coinbase transaction to the global transaction pool.
        this.GlobalTxPool.addTransaction(coinbaseTx);
    }


    /**
     * A subclass of Block, used to maintain the tree structure of the blockchain.
     * This subclass primarily manages the UTXO Pool status of each block node, as well as the transaction pool.
     */
    public class BlockNode {
        private final Block block; // The block associated with this node
        private int height; // The height of this block node in the blockchain
        private UTXOPool utxoPool; // The UTXO Pool status of this block node
        private BlockNode fatherNode; // The father block node
        private final ArrayList<BlockNode> kidNodes; // The kid block nodes

        /**
         * Constructor with parameters to initialize the block node.
         * @param block The block associated with this node
         * @param height The height of this block node in the blockchain
         * @param utxoPool The UTXO Pool status of this block node
         * @param fatherNode The father block node
         * @param kidNodes The kid block nodes
         */
        public BlockNode(Block block, int height, UTXOPool utxoPool,
                         BlockNode fatherNode, ArrayList<BlockNode> kidNodes) {
            this.block = block;
            this.height = height;
            this.utxoPool = utxoPool;
            this.fatherNode = fatherNode;
            this.kidNodes = kidNodes;
        }

        /**
         * Constructor to create a block node with a given block.
         * This constructor initializes height to 1 and creates an empty list of kid nodes and a new UTXO pool.
         * @param block The block associated with this node
         */
        public BlockNode(Block block) {
            this.block = block;
            this.height = 1;
            this.kidNodes = new ArrayList<BlockNode>();
            this.fatherNode = null;
            this.utxoPool = new UTXOPool();
        }

        /**
         * Retrieves the UTXO Pool status of this block node.
         * @return The UTXO Pool status of this block node
         */
        public UTXOPool getNode_UTXOPool() {
            return this.utxoPool;
        }

        /**
         * Retrieves the father block node of this block node.
         * @return The father block node
         */
        public BlockNode getNode_fatherNode() {
            return this.fatherNode;
        }

        /**
         * Retrieves the height of this block node in the blockchain.
         * @return The height of this block node
         */
        public int getNode_height() {
            return this.height;
        }

        /**
         * Retrieves the block associated with this block node.
         * @return The block associated with this block node
         */
        public Block getNode_block() {
            return this.block;
        }

        /**
         * Retrieves the list of child block nodes of this block node.
         * @return The list of child block nodes
         */
        public ArrayList<BlockNode> getNode_kidNodes() {
            return this.kidNodes;
        }

        /**
         * Adds a new block node object to the list of child nodes of a given father node.
         * @param fatherNode The father block node
         * @param block The new block to add
         * @return True if the addition is successful, otherwise false
         */
        public boolean addBlock(BlockNode fatherNode, Block block) {
            // Check if the previous block hash matches the hash of the father block node
            if (block.getPrevBlockHash() == null ||
                    !new ByteArrayWrapper(block.getPrevBlockHash()).equals(new ByteArrayWrapper(fatherNode.getNode_block().getHash()))) {
                return false;
            }

            // 检查新区块的高度是否满足截断年龄条件
            if (fatherNode.getNode_height() + 1 <= getNode_maxHeight(fatherNode).getNode_height() - CUT_OFF_AGE){
                // 如果新区块的高度加一之后，小于或等于当前区块链中最大高度的节点的高度减去截断年龄的值，则执行以下操作
                // 这里的截断年龄是用来限制区块链增长的速度，确保区块链的大小在可接受的范围内
                // 如果新区块的高度超过了允许的最大高度，就返回 false，表示不能添加新区块
                return false;
            }


            // Create a new UTXO pool from the father node's UTXO pool
            UTXOPool currentUTXOPool = new UTXOPool(fatherNode.getNode_UTXOPool());
            TxHandler kidTxHandler = new TxHandler(currentUTXOPool);
            // Handle the transactions of the new block
            Transaction[] kidTxs = block.getTransactions().toArray(new Transaction[block.getTransactions().size()]);
            Transaction[] kidValidTxs = kidTxHandler.handleTxs(kidTxs);

            // Check if all transactions are valid
            if (kidValidTxs.length != block.getTransactions().size()) {
                return false;
            }
            
            // Create a new block node for the new block
            BlockNode kidNode = new BlockNode(block);
            kidNode.fatherNode = fatherNode;
            fatherNode.kidNodes.add(kidNode);
            // Update the UTXO pool of the child node
            kidNode.utxoPool = kidTxHandler.getUTXOPool();
            kidNode.utxoPool.addUTXO(new UTXO(block.getCoinbase().getHash(),0), block.getCoinbase().getOutput(0));
            kidNode.height = fatherNode.getNode_height() + 1;

            // Output debug information
            out.println("Block hash code is: " + kidNode.getNode_block().hashCode());
            out.println("#kidNodes is: " + fatherNode.getNode_kidNodes().size());
            out.println("This is layer " + kidNode.height + " in the block chain");
            out.println("Size of UTXO pool is: " + kidNode.getNode_UTXOPool().getAllUTXO().size());
            out.println("#Txs in the block is: " + kidNode.getNode_block().getTransactions().size());
            out.println("Size of transaction pool is: " + getTransactionPool().getTransactions().size());
            out.println("-----------------------------");

            return true;
        }
    }

    /**
     * Print tree structure
     */
    public void printBlockChain(){
        out.println("the tree structure of block chain:");
        printBFSSearch(this.GenesisBlockNode);
    }



    /**
     * Perform Breadth-First Search (BFS) to print the blockchain tree structure.
     * @param blockNode The current block node being processed.
     */
    public static void printBFSSearch(BlockNode blockNode) {
        Queue<BlockNode> queue = new ArrayDeque<>();
        queue.add(blockNode);

        int currentLevelCount = 1;
        int nextLevelCount = 0;

        while (!queue.isEmpty()) {
            BlockNode currentNode = queue.poll();
            out.print("Block hash is: " + currentNode.getNode_block().hashCode() + " ");

            currentLevelCount--;

            queue.addAll(currentNode.getNode_kidNodes());
            nextLevelCount += currentNode.getNode_kidNodes().size();

            if (currentLevelCount == 0) {
                out.println(); // Move to the next line after printing all nodes in the current level
                currentLevelCount = nextLevelCount;
                nextLevelCount = 0;
            }
        }
    }


    /**
     * Get the longest branch from a given block node.
     * @param blockNode a claimed block node
     * @return the last block node in the longest branch
     */
    private BlockNode getNode_maxHeight(BlockNode blockNode) {
        if (blockNode.kidNodes.isEmpty()) {
            return blockNode;
        } else {
            int nodeHeight = blockNode.getNode_height();
            for (BlockNode kidNode : blockNode.getNode_kidNodes()) {
                BlockNode tempNode = getNode_maxHeight(kidNode);
                if (tempNode.getNode_height() > nodeHeight) {
                    nodeHeight = tempNode.getNode_height();
                    blockNode = tempNode;
                }
            }
            return blockNode;
        }
    }

    /**
     * Retrieve the most recent nodes to prevent overflow.
     * @param storeHeight The number of recent nodes to retrieve.
     * @param blockChain The blockchain from which to retrieve recent nodes.
     * @return A segment of the blockchain containing the most recent nodes.
     */
    public BlockChainSegment getNode_recentNodes(int storeHeight, BlockChain blockChain){
        BlockNode currentBlockNode = blockChain.getNode_maxHeight(blockChain.GenesisBlockNode);
        for(int i=0; i<storeHeight; i++){
            currentBlockNode = currentBlockNode.getNode_fatherNode();
        }
        return new BlockChainSegment(currentBlockNode);
    }


    /**
     * Get the block that is 'goBackHeight' blocks back from the maximum height block.
     * @param goBackHeight The number of blocks to go back from the maximum height block.
     * @return The block that is 'goBackHeight' blocks back.
     */
    public Block getGoBackBlock(int goBackHeight){
        BlockNode maxHeightBlockNode = getNode_maxHeight(this.GenesisBlockNode);
        for(int i=0; i<goBackHeight; i++){
            maxHeightBlockNode = maxHeightBlockNode.getNode_fatherNode();
        }
        return maxHeightBlockNode.getNode_block();
    }

    /**
     * Get the block node that is 'goBackHeight' blocks back from the maximum height block node.
     * @param goBackHeight The number of block nodes to go back from the maximum height block node.
     * @return The block node that is 'goBackHeight' blocks back.
     */
    private BlockNode getGoBackBlockNode(int goBackHeight){
        BlockNode maxHeightBlockNode = getNode_maxHeight(this.GenesisBlockNode);
        for(int i=0; i<goBackHeight; i++){
            maxHeightBlockNode = maxHeightBlockNode.getNode_fatherNode();
        }
        return maxHeightBlockNode;
    }

    /**
     * Get the block at the maximum height in the blockchain.
     * @return The block at the maximum height.
     */
    public Block getMaxHeightBlock() {
        return getNode_maxHeight(this.GenesisBlockNode).getNode_block();
    }


    /** Get the UTXOPool for mining a new block on top of max height block */
    public UTXOPool getMaxHeightUTXOPool() {
        // IMPLEMENT THIS
        return getNode_maxHeight(this.GenesisBlockNode).getNode_UTXOPool();
    }

    /** Get the transaction pool to mine a new block */
    public TransactionPool getTransactionPool() {
        // IMPLEMENT THIS
        return this.GlobalTxPool;
    }

    /**
     * Add {@code block} to the blockchain if it is valid. For a block to be considered valid,
     * all transactions within it must also be valid, and the block's height must be greater than
     * (maxHeight - CUT_OFF_AGE).
     * For example, you can attempt to create a new block on top of the genesis block (with a height of 2)
     * if the blockchain height is {@code <= CUT_OFF_AGE + 1}. This is because the blockchain is still in its early stages,
     * and the protocol allows for a limited number of blocks to be added directly on top of the genesis block.
     * However, once the blockchain height surpasses CUT_OFF_AGE + 1, you cannot create a new block at height 2 or
     * any height below (maxHeight - CUT_OFF_AGE). This restriction is enforced to prevent excessive growth of the blockchain
     * and maintain its integrity and efficiency.
     *
     * @param block The block to be added to the blockchain.
     * @return {@code true} if the block is successfully added, {@code false} otherwise.
     */

    public boolean addBlock(Block block) {
        // IMPLEMENT THIS
        // Get the node with maximum height
        BlockNode maxHeightBlockNode = getNode_maxHeight(this.GenesisBlockNode);

        // Check if the block is the genesis block and if the blockchain is not null
        if(block.getPrevBlockHash() == null && this.GenesisBlockNode != null){
            return false;
        }

        // Check if the previous block's hash matches the hash of the block with the maximum height
        if(!new ByteArrayWrapper(block.getPrevBlockHash()).equals(
                new ByteArrayWrapper(maxHeightBlockNode.getNode_block().getHash()))){
            return false;
        }

        // Attempt to add the block to the blockchain using the maximum height block node
        if(maxHeightBlockNode.addBlock(maxHeightBlockNode, block)){
            // Remove transactions in the new block from the global transaction pool
            for(Transaction tx : block.getTransactions()){
                this.GlobalTxPool.removeTransaction(tx.getHash());
            }

            // Add the coinbase transaction of the new block to the global transaction pool
            GlobalTxPool.addTransaction(block.getCoinbase());
            return true;
        } else {
            return false;
        }
    }

    /**
     * An extended version of add block that allows adding a block at a specific height relative to the current blockchain.
     *
     * @param block The block to be added to the blockchain.
     * @param goBackHeight The height to which the blockchain should go back before adding the new block.
     * @return {@code true} if the block is successfully added, {@code false} otherwise.
     */
    public boolean addBlockAtHeight(Block block, int goBackHeight) {
        // IMPLEMENT THIS
        // If the goBackHeight is 0, the operation is invalid
        if(goBackHeight == 0){
            return false;
        }

        // Get the block node at the specified goBackHeight
        BlockNode fatherBlockNode = getGoBackBlockNode(goBackHeight);

        // Check if the block is the genesis block and if the blockchain is not null
        if(block.getPrevBlockHash() == null && this.GenesisBlockNode != null){
            return false;
        }

        // Attempt to add the block to the blockchain using the block node at goBackHeight
        boolean status = fatherBlockNode.addBlock(fatherBlockNode, block);

        // If the block is successfully added, remove its transactions from the global transaction pool
        if(status){
            for(Transaction tx : block.getTransactions()){
                this.GlobalTxPool.removeTransaction(tx.getHash());
            }
            // Add the coinbase transaction of the new block to the global transaction pool
            GlobalTxPool.addTransaction(block.getCoinbase());
            return true;
        }
        return false;
    }


    /** Add a transaction to the transaction pool */
    public void addTransaction(Transaction tx) {
        // IMPLEMENT THIS
        this.GlobalTxPool.addTransaction(tx);
    }
}