import org.junit.Test;

import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.ArrayList;

import static java.lang.System.out;

public class TestMain {
    /**
     * Test1: A valid block chain
     * 1. Initializing Participants: It initializes participants (users) in the blockchain by generating key pairs.
     * 2. Creating Genesis Block: It creates the initial block, known as the genesis block, with a null previous block hash and a single coinbase transaction.
     * 3. Adding Blocks: It creates new blocks and adds them to the blockchain, while also processing transactions within these blocks.
     * 4. Adding Blocks with Manual Forking: It simulates manual forking by creating new blocks and adding them to a separate branch of the blockchain.
     * 5. Printing Blockchain Structure: It prints the structure of the blockchain by displaying the relationships between blocks, achieved through the printBlockChain method.
     * 6. Storing Partial Blockchain: It stores a partial length of the blockchain to prevent memory overflow, accomplished using the getNode_recentNodes method.
     * 7. And utxo pool is maintained by each block, transaction pool is maintained in a global view
     */
    @Test
    public void testValidBlockChain() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException {
        //init 8 players in the block chain
        ArrayList<KeyPair> users = BlockChainUtils.generateKeyPairs(8);
        //init genesis block 1M
        Block genesisBlock = new Block(null, users.get(0).getPublic());
        genesisBlock.finalize();
        //init block chain and corresponding block handler
        BlockChain blockChain = new BlockChain(genesisBlock);
        BlockHandler blockHandler = new BlockHandler(blockChain);


        //create block 2M, processBlock
        // init tx0：Coinbase_User0 -> User1, 25
        Transaction tx0 = BlockChainUtils.createTransaction(genesisBlock.getCoinbase().getHash(),0,
                25,0,users.get(1).getPublic(),users.get(0).getPrivate());
        // init block
        Block block2M = new Block(genesisBlock.getHash(), users.get(1).getPublic());
        block2M.addTransaction(tx0);
        block2M.finalize();
        // add block to the block chain
        out.println("Block 2M is created " );
        blockHandler.processBlock(block2M);


        //block 2B, processBlockManualFork
        // init tx1：Coinbase_User0 -> User2, 15
        Transaction tx1 = BlockChainUtils.createTransaction(genesisBlock.getCoinbase().getHash(),0,
                15,0,users.get(2).getPublic(),users.get(0).getPrivate());
        // init block
        Block block2B = new Block(genesisBlock.getHash(), users.get(2).getPublic());
        block2B.addTransaction(tx1);
        block2B.finalize();
        // add to block chain
        out.println("Block 2B is created " );
        blockHandler.processBlockManualFork(block2B, 1);

        //block 2BB, processBlockManualFork
        // init block
        Block block2BB = new Block(genesisBlock.getHash(), users.get(3).getPublic());
        block2BB.finalize();
        // add to block chain
        out.println("Block 2BB is created " );
        blockHandler.processBlockManualFork(block2BB, 1);

        // block 3M, processBlock
        Block block3M = new Block(block2M.getHash(), users.get(4).getPublic());
        block3M.finalize();
        // add to block chain
        out.println("Block 3M is created " );
        blockHandler.processBlock(block3M);

        // block 4M, processBlock
        // init tx2：Coinbase_User1 -> User4, 10
        // init tx3: Tx0_Output -> User3, 25
        Transaction tx2 = BlockChainUtils.createTransaction(block2M.getCoinbase().getHash(),0,
                10,0,users.get(4).getPublic(),users.get(1).getPrivate());
        Transaction tx3 = BlockChainUtils.createTransaction(tx0.getHash(),0,
                25,0,users.get(3).getPublic(),users.get(1).getPrivate());
        Block block4M = new Block(block3M.getHash(), users.get(5).getPublic());
        block4M.addTransaction(tx2);
        block4M.addTransaction(tx3);
        block4M.finalize();
        // add to block chain
        out.println("Block 4M is created " );
        blockHandler.processBlock(block4M);

        // block 4B processBlockManualFork
        Block block4B = new Block(block3M.getHash(), users.get(6).getPublic());
        block4B.finalize();
        // add to block chain
        out.println("Block 4B is created " );
        blockHandler.processBlockManualFork(block4B, 1);

        //create block 5M, processBlock
        // init tx4：Tx3  -> User4, 24
        Transaction tx4 = BlockChainUtils.createTransaction(tx3.getHash(),0,
                24,0,users.get(4).getPublic(),users.get(3).getPrivate());
        // init block
        Block block5M = new Block(block4M.getHash(), users.get(7).getPublic());
        block5M.addTransaction(tx4);
        block5M.finalize();
        // add block to the block chain
        out.println("Block 5M is created " );
        blockHandler.processBlock(block5M);

        blockChain.printBlockChain();
        // store partial block chain
        BlockChainSegment blockChainSegment = blockChain.getNode_recentNodes(2,blockChain);
        System.out.println("--------------------------------------");
        System.out.println("store a limited length of block chain:");
        blockChainSegment.printBlockChainSegment();
        System.out.println("--------------------------------------");
    }

    /**
     * Test2: Illegal fork
     * 1. fork at a valid position by processBlock, but the new block is created from wrong previous block's hash value.
     * 2. fork at a valid position by processBlockManualFork , but the new block is created from wrong previous block's hash value.
     * 3. fork at a invalid position, which is limited by CUT_OFF_AGE. For convenience, the CUT_OFF_AGE is reset to be 3.
     */
    @Test
    public void testIllegalFork() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException {
        //init 12 players in the block chain
        ArrayList<KeyPair> users = BlockChainUtils.generateKeyPairs(12);

        //create a new block chain for testing
        //genesis Block -> Block 1M -> Block 2M -> Block 3M -> Block 4M -> Block 5M

        //init genesis block
        Block genesisBlock = new Block(null, users.get(0).getPublic());
        genesisBlock.finalize();
        //init block chain and corresponding block handler
        BlockChain blockChain = new BlockChain(genesisBlock);
        BlockHandler blockHandler = new BlockHandler(blockChain);

        //create block 1M, processBlock
        // init tx
        Transaction tx0 = BlockChainUtils.createTransaction(genesisBlock.getCoinbase().getHash(), 0,
                10, 0, users.get(1).getPublic(), users.get(0).getPrivate());
        // init block
        Block block1M = new Block(genesisBlock.getHash(), users.get(1).getPublic());
        block1M.addTransaction(tx0);
        block1M.finalize();
        // add block to the block chain
        blockHandler.processBlock(block1M);

        // block 2M, processBlock
        Block block2M = new Block(block1M.getHash(), users.get(2).getPublic());
        block2M.finalize();
        // add to block chain
        blockHandler.processBlock(block2M);

        // block 3M, processBlock
        Block block3M = new Block(block2M.getHash(), users.get(3).getPublic());
        block3M.finalize();
        // add to block chain
        blockHandler.processBlock(block3M);

        // block 4M, processBlock
        Block block4M = new Block(block3M.getHash(), users.get(4).getPublic());
        block4M.finalize();
        // add to block chain
        blockHandler.processBlock(block4M);

        // block 5M, processBlock
        Block block5M = new Block(block4M.getHash(), users.get(5).getPublic());
        block5M.finalize();
        // add to block chain
        blockHandler.processBlock(block5M);

        out.println("Block chain for test is created: " );
        blockChain.printBlockChain();
        System.out.println("--------------------------------------");


        // 1. fork at a valid position by processBlock, but the new block is created from wrong previous block's hash value.
        // for details, the previous block of block 6M should be block 5M, but is set to be block 4M
        Block block6M = new Block(block4M.getHash(), users.get(6).getPublic());
        block6M.finalize();
        // add to block chain
        out.println("block 6M is created: " +  blockHandler.processBlock(block6M));


        // 2. fork at a valid position by processBlockManualFork , but the new block is created from wrong previous block's hash value.
        // for details, the previous block of block 6MM should be block 3M, but is set to be block 4M
        Block block6MM = new Block(block4M.getHash(), users.get(6).getPublic());
        block6MM.finalize();
        // add to block chain
        out.println("block 6MM is created: " +  blockHandler.processBlockManualFork(block6MM,2));

        // 3. fork at an invalid position, which is limited by CUT_OFF_AGE. For convenience, the CUT_OFF_AGE is reset to be 3.
        // the goBackHeight is set to be 4, larger than CUt_OFF_AGE
        Block block2B = new Block(block1M.getHash(), users.get(6).getPublic());
        block2B.finalize();
        // add to block chain
        out.println("block 2B is created: " +  blockHandler.processBlockManualFork(block2B,4));

        System.out.println("--------------------------------------");
        out.println("Block chain after test: " );
        blockChain.printBlockChain();
        System.out.println("--------------------------------------");

    }


    /**
     * Test3: Illegal coinbase
     * 1.use current block's coinbase in current block
     * 2.use an excessive number of coinbase
     */
    @Test
    public void testIllegalCoinbase() throws NoSuchAlgorithmException, SignatureException, InvalidKeyException {
        //init 3 players in the block chain
        ArrayList<KeyPair> users = BlockChainUtils.generateKeyPairs(3);
        //init genesis block
        Block genesisBlock = new Block(null, users.get(0).getPublic());
        genesisBlock.finalize();
        //init block chain and corresponding block handler
        BlockChain blockChain = new BlockChain(genesisBlock);
        BlockHandler blockHandler = new BlockHandler(blockChain);

        //create block 1M, processBlock, use current block's coinbase in current block
        // init block
        Block block1M = new Block(genesisBlock.getHash(), users.get(1).getPublic());
        // init tx
        Transaction tx0 = BlockChainUtils.createTransaction(block1M.getCoinbase().getHash(),0,
                10,0,users.get(1).getPublic(),users.get(0).getPrivate());
        block1M.addTransaction(tx0);
        block1M.finalize();
        // add block to the block chain
        out.println("block 1M is created: " +  blockHandler.processBlock(block1M));


        // create block 1MM, processBlock, use an excessive number of coinbase
        // init block
        Block block1MM = new Block(genesisBlock.getHash(), users.get(1).getPublic());
        // init tx
        Transaction tx1 = BlockChainUtils.createTransaction(genesisBlock.getCoinbase().getHash(),0,
                40,0,users.get(1).getPublic(),users.get(0).getPrivate());
        block1MM.addTransaction(tx1);
        block1MM.finalize();
        // add block to the block chain
        out.println("block 1MM is created: " +  blockHandler.processBlock(block1MM));

        blockChain.printBlockChain();
        System.out.println("--------------------------------------");
    }


}
