import java.security.*;
import java.util.ArrayList;

public class BlockChainUtils {

    /**
     * Initializes participants in a blockchain by generating key pairs.
     *
     * @param numberOfUsers The number of users for which key pairs need to be generated.
     * @return An ArrayList containing key pairs for the specified number of users.
     * @throws NoSuchAlgorithmException If the specified algorithm for key pair generation is not available.
     */
    public static ArrayList<KeyPair> generateKeyPairs(int numberOfUsers) throws NoSuchAlgorithmException {
        ArrayList<KeyPair> userArray = new ArrayList<>();
        for (int i = 0; i < numberOfUsers; i++) {
            userArray.add(KeyPairGenerator.getInstance("RSA").generateKeyPair());
        }
        return userArray;
    }

    /**
     * Initializes a transaction with one input and one output.
     *
     * @param prevTxHash       The hash of the previous transaction.
     * @param prevOutputIndex  The index of the previous transaction output.
     * @param coins            The amount of coins to be transferred.
     * @param inputIndex       The index of the input for signing.
     * @param receiverAddress  The public key of the receiver.
     * @param senderPrivateKey The private key of the sender.
     * @return The initialized transaction.
     * @throws NoSuchAlgorithmException If the specified algorithm for key pair generation is not available.
     * @throws InvalidKeyException      If the provided key is invalid.
     * @throws SignatureException       If an error occurs during signing.
     */
    public static Transaction createTransaction(byte[] prevTxHash, int prevOutputIndex, int coins, int inputIndex,
                                                    PublicKey receiverAddress, PrivateKey senderPrivateKey) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        Transaction tx = new Transaction();
        tx.addInput(prevTxHash, prevOutputIndex);
        tx.addOutput(coins, receiverAddress);
        tx.signTx(senderPrivateKey, inputIndex);
        return tx;
    }

    // Other utility methods can be added here if needed
}
